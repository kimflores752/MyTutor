//
//  StudentAccountViewController.swift
//  MY TUTOR
//
//  Created by PUNEET TOKHI on 12/2/16.
//  Copyright © 2016 Appmart. All rights reserved.
//

import UIKit
import GoogleSignIn

class StudentAccountViewController: UIViewController {

    @IBOutlet var yearTextBox: UITextField!
    @IBOutlet var userProfileNameLabel: UILabel!
    
    /*    tried to get the user's name on the profile creation, but failed
     if let tempUser = GIDSignIn.sharedInstance().currentUser {
     self.userProfileNameLabel.text = "\(tempUser.profile.name!)"
     */

    
    @IBOutlet var dropDown: UIPickerView!
    
    //list of years
    var listYear = ["Freshman", "Sophomore", "Junior", "Senior", "Graduate Student"]
    
    
    
  /*
    @IBAction func createStudentAccountAction(_ sender: Any) {
        
        if self.emailTextField.text == "" || self.passwordTextField.text == "" || self.firstNameTextField.text == ""
        {
            let alertController = UIAlertController(title: "Oops!", message: "Please fill all the required fields before proceeding...", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            
            alertController.addAction(defaultAction)
            
            self.present(alertController, animated: true, completion: nil)
            
            
        }
        
    }
*/
    @IBOutlet var emailTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    @IBOutlet var firstNameTextField: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //drop down menu stuff
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return listYear.count
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String! {
        
        self.view.endEditing(true)
        return listYear[row]
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        self.yearTextBox.text = self.listYear[row]
        self.dropDown.isHidden = true
    }
    
    func textFieldDidBeginEditing(textField: UITextField){
        
        if textField == self.yearTextBox {
            self.dropDown.isHidden = true
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
