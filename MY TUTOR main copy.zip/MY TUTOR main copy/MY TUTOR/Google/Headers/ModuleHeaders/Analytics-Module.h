#if defined(__has_include)
# if __has_include(<GGLAnalytics/GGLAnalytics.h>)
#  include <GGLAnalytics/GGLAnalytics.h>
# endif
#endif
