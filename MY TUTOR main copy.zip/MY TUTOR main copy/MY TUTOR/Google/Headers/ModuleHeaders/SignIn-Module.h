#if defined(__has_include)
# if __has_include(<GGLSignIn/GGLSignIn.h>)
#  include <GGLSignIn/GGLSignIn.h>
# endif
#endif
