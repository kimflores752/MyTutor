#if defined(__has_include)
# if __has_include(<GGLCore/GGLCore.h>)
#  include <GGLCore/GGLCore.h>
# endif
#endif
