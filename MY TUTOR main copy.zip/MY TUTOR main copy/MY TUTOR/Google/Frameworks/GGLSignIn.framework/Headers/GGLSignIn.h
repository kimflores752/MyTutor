// Generated umbrella header for GGLSignIn.

#import "GGLContext+SignIn.h"
