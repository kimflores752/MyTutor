#import <Foundation/Foundation.h>
@interface PodsDummy_GTMOAuth2 : NSObject
@end
@implementation PodsDummy_GTMOAuth2
@end
