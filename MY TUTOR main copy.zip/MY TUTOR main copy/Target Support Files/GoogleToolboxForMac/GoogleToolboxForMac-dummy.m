#import <Foundation/Foundation.h>
@interface PodsDummy_GoogleToolboxForMac : NSObject
@end
@implementation PodsDummy_GoogleToolboxForMac
@end
